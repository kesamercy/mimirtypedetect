package example

object Main {
  def Main() = {
    val ages = Seq(42, 61, 29, 64)
    println("The oldest person is ${ages.max}")
  }
}
