
class testCases {

  // declare  variables

  var dataSeq:Seq[String] = Seq(

    "Main 66  4/1/2001  Street 10/12/2018 88 Suite 101",

    "today is 4/1/2001 and tomorrow will be 10/12/2018 and next year will be 5/2/2019",

    "the time is  18:30 should 14:00 leave at 22:39",

    "this is true he is false true",

    " 0.4 0.9 0.5 0.66 0.77 0.55"



  )

}

